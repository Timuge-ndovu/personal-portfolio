# Prince Kimutai (Ndovu) — Portfolio

A single-file, self-contained portfolio website (HTML + CSS + JS, no build step, no dependencies to install). The background photo is embedded directly in the HTML as base64, so this one file is everything you need.

## ▶️ Run it locally

**Easiest way:** just double-click `index.html` — it opens directly in your browser. No server needed.

**Optional (if you want it served over `http://` instead of `file://`):**

```bash
# Python 3
python3 -m http.server 8000

# then open:
# http://localhost:8000
```

## ⬆️ Upload to GitHub

1. Create a new repository on GitHub (e.g. `ndovu-portfolio`) — don't initialize it with a README, since you already have one here.
2. In this folder, run:
   ```bash
   git init
   git add .
   git commit -m "Initial portfolio commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo-name>.git
   git push -u origin main
   ```

## 🌐 Publish it for free with GitHub Pages

1. On GitHub, open your repo → **Settings** → **Pages**.
2. Under "Build and deployment", set **Source** to `Deploy from a branch`.
3. Set **Branch** to `main` and folder to `/ (root)`, then **Save**.
4. After a minute, your site will be live at:
   ```
   https://<your-username>.github.io/<your-repo-name>/
   ```

## ✏️ Before you go live — things to fix

- The contact form's Web3Forms `access_key` is still a placeholder (`YOUR_WEB3FORMS_KEY_HERE`) — get a free key at [web3forms.com](https://web3forms.com) and paste it into `index.html` (search for `access_key`), or the form will silently fail.
- Double-check the GitHub link in the Contact section points to your real profile.
